
def main():
    print('Modulo FFT.')